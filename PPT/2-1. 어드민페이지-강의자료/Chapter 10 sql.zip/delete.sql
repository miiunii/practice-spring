truncate table admin_user;
truncate table category;
truncate table item;
truncate table order_detail;
truncate table order_group;
truncate table partner;
truncate table user;